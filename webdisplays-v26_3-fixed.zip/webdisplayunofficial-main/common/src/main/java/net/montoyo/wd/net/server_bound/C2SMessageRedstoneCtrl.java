/*
 * Copyright (C) 2018 BARBOTIN Nicolas
 */

package net.montoyo.wd.net.server_bound;

import net.montoyo.wd.net.NetworkEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.montoyo.wd.core.ScreenRights;
import net.montoyo.wd.entity.RedstoneControlBlockEntity;
import net.montoyo.wd.entity.ScreenBlockEntity;
import net.montoyo.wd.net.AbstractPacket;
import net.montoyo.wd.utilities.serialization.Util;
import net.montoyo.wd.utilities.math.Vector3i;

public class C2SMessageRedstoneCtrl extends AbstractPacket implements Runnable {
	private Player player;
	private Vector3i pos;
	private String risingEdgeURL;
	private String fallingEdgeURL;
	
	public C2SMessageRedstoneCtrl() {
	}
	
	public C2SMessageRedstoneCtrl(Vector3i p, String r, String f) {
		pos = p;
		risingEdgeURL = r;
		fallingEdgeURL = f;
	}
	
	public C2SMessageRedstoneCtrl(FriendlyByteBuf buf) {
		super(buf);
		pos = new Vector3i(buf);
		risingEdgeURL = buf.readUtf();
		fallingEdgeURL = buf.readUtf();
	}
	
	@Override
	public void run() {
		Level world = player.level();
		BlockPos blockPos = pos.toBlock();
		// Use default reach distance of 5 blocks (Fabric doesn't have ForgeMod.BLOCK_REACH)
		final double maxRange = 5.0;
		
		if (player.distanceToSqr(blockPos.getX(), blockPos.getY(), blockPos.getZ()) > maxRange * maxRange)
			return;
		
		BlockEntity te = world.getBlockEntity(blockPos);
		if (te == null || !(te instanceof RedstoneControlBlockEntity))
			return;
		
		RedstoneControlBlockEntity redCtrl = (RedstoneControlBlockEntity) te;
		if (!redCtrl.isScreenChunkLoaded()) {
			Util.toast(player, "chunkUnloaded");
			return;
		}
		
		ScreenBlockEntity tes = redCtrl.getConnectedScreen();
		if (tes == null)
			return;
		
		if ((tes.getScreen(redCtrl.getScreenSide()).rightsFor(player) & ScreenRights.CHANGE_URL) == 0)
			return;
		
		redCtrl.setURLs(risingEdgeURL, fallingEdgeURL);
	}
	
	@Override
	public void write(FriendlyByteBuf buf) {
		pos.writeTo(buf);
		buf.writeUtf(risingEdgeURL);
		buf.writeUtf(fallingEdgeURL);
	}
	
	@Override
	public net.minecraft.resources.ResourceLocation getId() {
		return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("webdisplays", "redstonectrl");
	}
	
	public void handle(NetworkEvent.Context ctx) {
		if (checkServer(ctx)) {
			player = ctx.getSender();
			ctx.enqueueWork(this);
			ctx.setPacketHandled(true);
		}
	}

	@Override
	public void handle(Player player) {
		if (player.level().isClientSide) return;
		this.player = player;
		run();
	}
}
