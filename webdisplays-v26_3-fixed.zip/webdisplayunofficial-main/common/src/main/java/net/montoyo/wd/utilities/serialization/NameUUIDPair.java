/*
 * Copyright (C) 2018 BARBOTIN Nicolas
 */

package net.montoyo.wd.utilities.serialization;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;

public final class NameUUIDPair {
    public final String name;
    public final UUID uuid;

    public NameUUIDPair() {
        name = "";
        uuid = new UUID(0L, 0L);
    }

    public NameUUIDPair(String name, UUID uuid) {
        this.name = name;
        this.uuid = uuid;
    }

    public NameUUIDPair(GameProfile profile) {
        name = profile.getName();
        uuid = profile.getId();
    }

    public NameUUIDPair(FriendlyByteBuf bb) {
        name = bb.readUtf();

        long msb = bb.readLong();
        long lsb = bb.readLong();
        uuid = new UUID(msb, lsb);
    }

    public String getName() {
        return name;
    }

    public UUID getUUID() {
        return uuid;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof NameUUIDPair))
            return false;

        return ((NameUUIDPair) obj).uuid.equals(uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }

    public boolean isBlank() {
        return name.isEmpty() && uuid.getMostSignificantBits() == 0L && uuid.getLeastSignificantBits() == 0L;
    }

    public void writeTo(FriendlyByteBuf bb) {
        bb.writeUtf(name);
        bb.writeLong(uuid.getMostSignificantBits());
        bb.writeLong(uuid.getLeastSignificantBits());
    }
}
